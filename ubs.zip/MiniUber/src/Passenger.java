import java.util.Random;

import com.google.gson.Gson;

public class Passenger extends Account{

	public Passenger(String name, float balance, Location loc){
		super(name, balance, loc);
	}


}
